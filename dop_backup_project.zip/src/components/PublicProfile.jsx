import React, { useState, useEffect } from 'react';
import { ArrowRight, Crown, Zap, Grid, CircleDollarSign, UserPlus, UserCheck } from 'lucide-react';
import { supabase } from '../supabase';

const PublicProfile = ({ userId, currentUserId, onClose }) => {
  const [profileUser, setProfileUser] = useState(null);
  const [drops, setDrops] = useState([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;
    fetchData();
    checkIfFollowing();
  }, [userId]);

  const fetchData = async () => {
    setLoading(true);
    // שליפת נתוני המשתמש
    const { data: userData } = await supabase.from('dop_users').select('*').eq('id', userId).single();
    if (userData) setProfileUser(userData);
    
    // שליפת הדרופים שלו
    const { data: dropsData } = await supabase.from('dop_videos').select('*').eq('user_id', userId).order('created_at', { ascending: false });
    if (dropsData) setDrops(dropsData);
    
    setLoading(false);
  };

  const checkIfFollowing = async () => {
    try {
      // בדיקה אם טבלת העוקבים קיימת והאם המשתמש כבר עוקב
      const { data } = await supabase.from('dop_follows').select('*').eq('follower_id', currentUserId).eq('following_id', userId).single();
      if (data) setIsFollowing(true);
    } catch(e) { /* מתעלם אם הטבלה עדיין לא נוצרה במסד הנתונים */ }
  };

  const handleFollow = async () => {
    setIsFollowing(!isFollowing); // שינוי ויזואלי מיידי
    try {
      if (!isFollowing) {
        await supabase.from('dop_follows').insert({ follower_id: currentUserId, following_id: userId });
      } else {
        await supabase.from('dop_follows').delete().eq('follower_id', currentUserId).eq('following_id', userId);
      }
    } catch(e) { console.log('Follow action error:', e); }
  };

  if (loading) return <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center text-white font-mono text-sm">טוען פרופיל...</div>;
  if (!profileUser) return null;

  const totalDrops = drops.length;
  const rawCoins = profileUser.dop_coins || 0;
  const totalCoins = Intl.NumberFormat('en-US', { notation: "compact", maximumFractionDigits: 1 }).format(rawCoins);
  const totalBoosts = drops.reduce((sum, drop) => sum + (drop.boosts || 0), 0);

  return (
    <div className="fixed inset-0 bg-black z-50 overflow-y-auto pb-28 hide-scrollbar animate-in slide-in-from-right duration-300" dir="rtl">
      
      {/* רקע עליון וכפתור חזור */}
      <div className="h-48 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-800 via-zinc-950 to-black relative border-b border-white/5">
        <button onClick={onClose} className="absolute top-10 right-4 p-3 bg-white/5 hover:bg-white/10 backdrop-blur-2xl rounded-2xl text-white border border-white/5 active:scale-95 transition-all shadow-xl z-20">
          <ArrowRight size={20} />
        </button>
      </div>

      <div className="px-4 relative -mt-24 flex flex-col items-center">
        {/* תמונת פרופיל */}
        <div className={`w-36 h-36 rounded-full bg-zinc-900 border-[6px] ${profileUser.has_halo ? 'border-yellow-400 shadow-[0_0_50px_rgba(250,204,21,0.4)]' : 'border-black shadow-[0_20px_40px_rgba(0,0,0,0.8)]'} overflow-hidden flex items-center justify-center relative z-10`}>
          {profileUser.avatar_url ? <img src={profileUser.avatar_url} alt="Avatar" className="w-full h-full object-cover" /> : <span className="text-5xl font-black text-white/20">@</span>}
        </div>

        {/* שם משתמש */}
        <h2 className={`mt-5 text-3xl font-black flex items-center gap-2 tracking-wide ${profileUser.has_halo ? 'text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.6)]' : 'text-white'}`}>
          {profileUser.has_halo && <Crown size={28} className="text-yellow-400" />}
          @{profileUser.username}
        </h2>

        {/* קישור לפרופיל (אם יש) */}
        {profileUser.profile_link && (
          <a href={profileUser.profile_link.startsWith('http') ? profileUser.profile_link : `https://${profileUser.profile_link}`} target="_blank" rel="noopener noreferrer" className="mt-3 px-6 py-2.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-bold flex items-center gap-2 hover:bg-blue-500/20 transition-all shadow-lg" dir="ltr">
            <span className="truncate max-w-[160px]">{profileUser.profile_link.replace(/^https?:\/\//, '')}</span>
          </a>
        )}

        {/* כפתור עקוב */}
        {currentUserId !== userId && (
          <button 
            onClick={handleFollow} 
            className={`mt-6 px-12 py-3.5 rounded-[1.5rem] font-black text-sm flex items-center gap-2 transition-all active:scale-95 shadow-xl ${isFollowing ? 'bg-white/10 text-white border border-white/20' : 'bg-white text-black hover:bg-gray-200'}`}
          >
            {isFollowing ? <><UserCheck size={18}/> עוקב</> : <><UserPlus size={18}/> לעקוב</>}
          </button>
        )}

        {/* סטטיסטיקות */}
        <div className="flex gap-3 w-full max-w-sm mt-8 px-1">
          <div className="flex-[1.2] flex flex-col items-center justify-center bg-gradient-to-b from-yellow-500/10 to-white/5 backdrop-blur-2xl border border-yellow-500/20 rounded-[2rem] p-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-24 bg-yellow-400/20 blur-3xl"></div>
            <CircleDollarSign size={28} className="text-yellow-400 mb-3" />
            <span className="text-4xl font-black text-yellow-400">{totalCoins}</span>
            <span className="text-[11px] text-yellow-400/80 font-bold uppercase tracking-widest mt-2">מטבעות</span>
          </div>
          <div className="flex-1 flex flex-col gap-3">
            <div className="flex-1 flex flex-col items-center justify-center bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[1.5rem] py-4 shadow-xl">
              <span className="text-2xl font-black text-white">{totalDrops}</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">דרופים</span>
            </div>
            <div className="flex-1 flex flex-col items-center justify-center bg-white/5 backdrop-blur-2xl border border-blue-500/20 rounded-[1.5rem] py-4 shadow-xl relative overflow-hidden">
              <div className="absolute inset-0 bg-blue-400/10 blur-2xl"></div>
              <span className="text-2xl font-black text-blue-400">{totalBoosts}</span>
              <span className="text-[10px] text-blue-400/80 font-bold uppercase tracking-widest mt-1">בוסטים</span>
            </div>
          </div>
        </div>
      </div>

      {/* גריד דרופים של המשתמש */}
      <div className="mt-12 px-3">
        <div className="flex items-center justify-between mb-5 px-2">
          <h3 className="text-white font-black tracking-widest text-lg drop-shadow-md">הדרופים של {profileUser.username}</h3>
        </div>
        
        <div className="grid grid-cols-3 gap-2">
          {drops.map(drop => {
            const isImage = drop.video_url?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
            return (
              <div key={drop.id} className="aspect-[3/4] bg-zinc-900 relative overflow-hidden group rounded-2xl border border-white/5 shadow-lg">
                {isImage ? <img src={drop.video_url} className="w-full h-full object-cover opacity-80" /> : <video src={drop.video_url} className="w-full h-full object-cover opacity-80" />}
                <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xl rounded-full px-2.5 py-1 flex items-center gap-1.5 border border-white/10">
                  <Zap size={12} className="text-blue-400" />
                  <span className="text-xs text-white font-bold">{drop.boosts || 0}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  );
};
export default PublicProfile;
