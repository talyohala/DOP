import React, { useState, useEffect } from 'react';
import { X, Send } from 'lucide-react';
import { supabase } from '../supabase';

const CommentsOverlay = ({ videoId, onClose }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);

  // נעילת גלילת הרקע למניעת קפיצות מסך
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    fetchComments();
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [videoId]);

  const fetchComments = async () => {
    try {
      const { data } = await supabase
        .from('dop_comments')
        .select('*, users:user_id(username, avatar_url, has_halo)')
        .eq('video_id', videoId)
        .order('created_at', { ascending: true });
      if (data) setComments(data);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { data } = await supabase
        .from('dop_comments')
        .insert({ video_id: videoId, user_id: user.id, text: newComment })
        .select('*, users:user_id(username, avatar_url, has_halo)')
        .single();
        
      if (data) setComments([...comments, data]);
      setNewComment('');
    } catch (e) { console.error(e); }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm"
      onClick={onClose}
      style={{ overscrollBehavior: 'contain' }}
    >
      <div 
        className="bg-[#0a0a0a] w-full h-[75vh] rounded-t-[2.5rem] flex flex-col shadow-[0_-20px_50px_rgba(0,0,0,0.8)] border-t border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mt-4 mb-2"></div>
        
        {/* כותרת */}
        <div className="flex items-center justify-between px-6 pb-4 pt-2 border-b border-white/10">
          <h3 className="text-white font-black tracking-widest text-lg">תגובות ({comments.length})</h3>
          <button onClick={onClose} className="p-2.5 bg-white/5 hover:bg-white/10 rounded-full text-white active:scale-95 transition-all"><X size={20}/></button>
        </div>

        {/* רשימת תגובות */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 hide-scrollbar">
          {loading ? (
             <div className="text-center text-gray-500 mt-8 text-sm font-medium">טוען תגובות...</div>
          ) : comments.length === 0 ? (
            <div className="text-center text-gray-500 mt-12 text-sm font-medium">היה הראשון להגיב! ✨</div>
          ) : (
            comments.map(c => (
              <div key={c.id} className="flex gap-3">
                <div className={`w-9 h-9 rounded-full bg-zinc-800 flex-shrink-0 flex items-center justify-center border-2 ${c.users?.has_halo ? 'border-yellow-400 shadow-[0_0_10px_rgba(250,204,21,0.3)]' : 'border-transparent'}`}>
                  {c.users?.avatar_url ? <img src={c.users.avatar_url} className="w-full h-full rounded-full object-cover"/> : <span className="text-sm font-black text-white/50">@</span>}
                </div>
                <div className="bg-white/5 border border-white/5 rounded-2xl rounded-tr-none px-4 py-2.5 max-w-[85%] shadow-md">
                  <span className={`text-xs font-bold block mb-1 ${c.users?.has_halo ? 'text-yellow-400' : 'text-gray-400'}`}>{c.users?.username || 'אנונימי'}</span>
                  <p className="text-sm text-white/90 leading-snug">{c.text}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* שורת הקלדה */}
        <div className="p-4 border-t border-white/10 bg-[#0a0a0a] pb-8">
          <form onSubmit={handleSend} className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full p-1.5 pl-5 shadow-lg">
            <input 
              type="text" 
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="הוסף תגובה..."
              className="flex-1 bg-transparent text-white text-sm outline-none placeholder:text-gray-500"
            />
            <button type="submit" disabled={!newComment.trim()} className="p-2.5 bg-blue-500 hover:bg-blue-600 disabled:bg-white/5 disabled:text-gray-600 text-white rounded-full transition-all active:scale-95">
              <Send size={18} className="ml-0.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CommentsOverlay;
