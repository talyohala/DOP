import React, { useState } from 'react';
import { Fingerprint, Zap, Shield, Crown, Snowflake, RefreshCw, X, CircleDollarSign, Ghost, Target } from 'lucide-react';
import BlackMarket from './BlackMarket';

const Store = ({ userCoins, onPurchase, onClose }) => {
  const [showBlackMarket, setShowBlackMarket] = useState(false);

  const formattedCoins = Intl.NumberFormat('en-US', { 
    notation: "compact", 
    maximumFractionDigits: 1,
    minimumFractionDigits: 1
  }).format(userCoins || 0);

  const items = [
    { id: 1, name: 'זריקת אנרגיה', desc: 'מוסיף 60 דקות לדרופ שלך באופן מיידי.', price: 100.0, icon: <Zap size={40} className="text-blue-500" />, bg: 'from-blue-500/10' },
    { id: 2, name: 'מגן זמן', desc: 'מגן על הדרופ שלך משאיבת זמן למשך שעתיים.', price: 250.0, icon: <Shield size={40} className="text-emerald-500" />, bg: 'from-emerald-500/10' },
    { id: 3, name: 'הקפאת שעון', desc: 'עוצר את הזמן של הדרופ שלך למשך שעה שלמה.', price: 500.0, icon: <Snowflake size={40} className="text-cyan-400" />, bg: 'from-cyan-400/10' },
    { id: 4, name: 'הילת זהב', desc: 'מסגרת VIP זוהרת סביב הפרופיל שלך למשך שבוע.', price: 1000.0, icon: <Crown size={40} className="text-yellow-500" />, bg: 'from-yellow-500/10' },
    { id: 5, name: 'תחיית המתים', desc: 'מחזיר לחיים דרופ שנשאב כבר לחור השחור.', price: 2000.0, icon: <RefreshCw size={40} className="text-orange-500" />, bg: 'from-orange-500/10' },
    { id: 6, name: 'מגנט בוסטים', desc: 'מכפיל את כמות הבוסטים שאתה מקבל למשך 10 דקות.', price: 800.0, icon: <Target size={40} className="text-purple-500" />, bg: 'from-purple-500/10' },
    { id: 7, name: 'מצב רוח רפאים', desc: 'הפוך לבלתי נראה בפיד ל-30 דקות.', price: 400.0, icon: <Ghost size={40} className="text-zinc-400" />, bg: 'from-zinc-400/10' },
  ];

  if (showBlackMarket) {
    return <BlackMarket userCoins={userCoins} onClose={() => setShowBlackMarket(false)} onPurchase={onPurchase} />;
  }

  return (
    <div className="fixed inset-0 bg-[#050505] z-50 flex flex-col font-sans text-white animate-in slide-in-from-bottom duration-300" dir="rtl">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,_var(--tw-gradient-stops))] from-blue-900/20 via-[#050505] to-[#050505] opacity-80 pointer-events-none"></div>
      
      <div className="relative z-10 p-6 flex justify-between items-start">
        <div>
          <h2 className="text-4xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-zinc-200 to-zinc-500">
            השוק השחור
          </h2>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-zinc-500 text-xs font-bold tracking-widest uppercase italic">מסחר מורשה</span>
            <button onClick={() => setShowBlackMarket(true)} className="text-zinc-700 hover:text-cyan-400 transition-colors">
              <Fingerprint size={18} />
            </button>
          </div>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-full backdrop-blur-md transition-all active:scale-90 border border-white/5">
          <X size={20} />
        </button>
      </div>

      <div className="relative z-10 px-6 mt-2">
         <div className="inline-flex items-center gap-3 bg-zinc-900/40 border border-zinc-800 rounded-full py-2.5 px-5 backdrop-blur-md shadow-lg">
            <CircleDollarSign size={20} className="text-zinc-400" />
            <span className="text-2xl font-black tracking-wider text-white">{formattedCoins} DOP</span>
         </div>
      </div>

      <div className="relative z-10 flex-1 flex items-center overflow-x-auto snap-x snap-mandatory px-6 pb-12 pt-4 hide-scrollbar space-x-4 space-x-reverse">
         {items.map(item => (
           <div key={item.id} className="snap-center shrink-0 w-[85vw] max-w-sm h-[60vh] bg-zinc-900/30 border border-zinc-800/80 rounded-[2.5rem] p-8 flex flex-col justify-between hover:border-zinc-600 transition-all overflow-hidden relative group ml-4 shadow-2xl">
             <div className={`absolute -inset-20 bg-gradient-to-br ${item.bg} to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-3xl z-0 pointer-events-none`}></div>
             
             <div className="relative z-10 text-right">
               <div className="flex justify-between items-start mb-10">
                 <div className="p-4 bg-black/50 rounded-2xl border border-zinc-800 shadow-xl group-hover:scale-110 transition-transform duration-500 backdrop-blur-sm">
                   {item.icon}
                 </div>
                 <div className="text-left bg-black/40 px-4 py-2 rounded-2xl border border-zinc-800/50 backdrop-blur-sm" dir="ltr">
                   <span className="text-[10px] font-bold text-zinc-500 block mb-0.5 tracking-widest uppercase">Price</span>
                   <span className="text-xl font-black text-white">{item.price.toFixed(1)}</span>
                 </div>
               </div>
               
               <h3 className="text-3xl font-black mb-4 tracking-wide text-white">{item.name}</h3>
               <p className="text-zinc-400 text-sm leading-relaxed font-medium">{item.desc}</p>
             </div>

             <button onClick={() => onPurchase(item)} className="relative z-10 w-full py-4.5 bg-white text-black font-black text-lg rounded-2xl active:scale-95 transition-all hover:bg-zinc-200">
               רכוש כעת
             </button>
           </div>
         ))}
      </div>
    </div>
  );
};

export default Store;
