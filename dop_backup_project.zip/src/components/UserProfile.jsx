import React, { useState } from 'react';
import { Crown, Zap, Grid, CircleDollarSign, LogOut, Settings, X, ChevronLeft, Link as LinkIcon, Check, Edit2, Trash2, Pencil, Camera, Loader2 } from 'lucide-react';
import { supabase } from '../supabase';

const UserProfile = ({ user, drops }) => {
  const [showSettings, setShowSettings] = useState(false);
  const [activeSettingModal, setActiveSettingModal] = useState(null);
  const [dropToDelete, setDropToDelete] = useState(null);
  const [dropToEdit, setDropToEdit] = useState(null);
  const [editDescription, setEditDescription] = useState('');
  const [isEditingLink, setIsEditingLink] = useState(false);
  const [linkValue, setLinkValue] = useState(user?.social_link || '');
  const [editUsername, setEditUsername] = useState(user?.username || '');
  const [uploading, setUploading] = useState(false);

  if (!user) return null;

  const totalDrops = drops.length;
  const totalCoins = Intl.NumberFormat('en-US', { notation: "compact", maximumFractionDigits: 1 }).format(user.dop_coins || 0);
  const totalBoosts = drops.reduce((sum, drop) => sum + (drop.boosts || 0), 0);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  const handleAvatarUpload = async (event) => {
    try {
      setUploading(true);
      if (!event.target.files || event.target.files.length === 0) return;
      
      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `public/${fileName}`;

      // העלאה ל-Storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // קבלת הקישור הציבורי
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      // עדכון ב-Database
      const { error: updateError } = await supabase
        .from('dop_users')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;
      
      window.location.reload();
    } catch (error) {
      console.error('Error uploading avatar:', error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      const { error } = await supabase.from('dop_users').update({ 
        username: editUsername, 
        social_link: linkValue 
      }).eq('id', user.id);
      
      if (error) throw error;
      window.location.reload();
    } catch (error) {
      console.error('Error saving:', error.message);
    }
  };

  const confirmDelete = async () => {
    if (dropToDelete) {
      await supabase.from('dop_videos').delete().eq('id', dropToDelete);
      setDropToDelete(null);
      window.location.reload();
    }
  };

  const renderSettingContent = () => {
    if (activeSettingModal === 'עריכת פרופיל') {
      return (
        <div className="space-y-8 mt-4">
          {/* עריכת תמונה */}
          <div className="flex flex-col items-center gap-4">
            <div className="relative group">
              <div className="w-32 h-32 rounded-full bg-zinc-800 border-4 border-white/5 overflow-hidden flex items-center justify-center">
                {uploading ? (
                  <Loader2 className="text-white animate-spin" size={32} />
                ) : user.avatar_url ? (
                  <img src={user.avatar_url} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-4xl text-white/20">@</span>
                )}
              </div>
              <label className="absolute bottom-0 right-0 p-2.5 bg-blue-500 rounded-full text-white cursor-pointer shadow-xl active:scale-90 transition-all">
                <Camera size={18} />
                <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} disabled={uploading} />
              </label>
            </div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">לחץ לעדכון תמונה</p>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 mr-2 uppercase tracking-tighter">שם משתמש</label>
              <input type="text" value={editUsername} onChange={(e) => setEditUsername(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white outline-none focus:border-blue-500/50" dir="ltr" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 mr-2 uppercase tracking-tighter">קישור אישי</label>
              <input type="url" value={linkValue} onChange={(e) => setLinkValue(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white outline-none focus:border-blue-500/50" dir="ltr" placeholder="https://..." />
            </div>
            <button onClick={handleSaveProfile} className="w-full py-4.5 bg-white text-black font-black rounded-2xl shadow-xl active:scale-95 transition-all mt-4">שמור שינויים</button>
          </div>
        </div>
      );
    }
    return <div className="text-center text-gray-500 mt-20 font-bold italic tracking-widest uppercase opacity-20">Settings for {activeSettingModal} coming soon</div>;
  };

  return (
    <div className="h-[100dvh] w-full bg-black overflow-y-auto pb-28 hide-scrollbar" dir="rtl">
      
      <div className="h-48 bg-gradient-to-b from-zinc-800/50 to-black relative border-b border-white/5">
        <div className="absolute top-12 left-4 flex gap-3 z-20">
          <button onClick={handleLogout} className="p-3 bg-red-500/10 rounded-2xl text-red-400 border border-red-500/10 active:scale-95"><LogOut size={18} /></button>
          <button onClick={() => setShowSettings(true)} className="p-3 bg-white/5 rounded-2xl text-white border border-white/10 active:scale-95"><Settings size={18} /></button>
        </div>
      </div>

      <div className="px-4 relative -mt-20 flex flex-col items-center">
        <div className={`w-36 h-36 rounded-full bg-zinc-900 border-[6px] ${user.has_halo ? 'border-yellow-400 shadow-[0_0_50px_rgba(250,204,21,0.3)]' : 'border-black'} overflow-hidden relative z-10 shadow-2xl`}>
          {user.avatar_url ? <img src={user.avatar_url} className="w-full h-full object-cover" /> : <span className="text-5xl text-white/10 flex items-center justify-center h-full font-black">@</span>}
        </div>
        <h2 className={`mt-5 text-3xl font-black flex items-center gap-2 tracking-tighter ${user.has_halo ? 'text-yellow-400' : 'text-white'}`}>
          {user.has_halo && <Crown size={24} className="text-yellow-400" />}
          @{user.username || 'אנונימי'}
        </h2>
        
        {user.social_link && (
          <a href={user.social_link} target="_blank" className="mt-4 text-blue-400 font-black text-xs flex items-center gap-2 bg-blue-500/5 px-6 py-2 rounded-full border border-blue-500/10 shadow-lg" dir="ltr">
            <LinkIcon size={14} /> {user.social_link.replace(/^https?:\/\//, '')}
          </a>
        )}

        <div className="flex gap-3 w-full max-w-sm mt-10">
          <div className="flex-[1.2] bg-zinc-900/50 border border-white/5 rounded-[2.5rem] p-6 flex flex-col items-center shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-20 bg-yellow-500/5 blur-3xl"></div>
            <CircleDollarSign size={24} className="text-yellow-500/50 mb-3" />
            <span className="text-4xl font-black text-white">{totalCoins}</span>
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em] mt-2">DOP Coins</span>
          </div>
          <div className="flex-1 flex flex-col gap-3">
            <div className="flex-1 bg-zinc-900/50 border border-white/5 rounded-3xl flex flex-col items-center justify-center py-4">
              <span className="text-2xl font-black text-white">{totalDrops}</span>
              <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Drops</span>
            </div>
            <div className="flex-1 bg-zinc-900/50 border border-white/5 rounded-3xl flex flex-col items-center justify-center py-4">
              <span className="text-2xl font-black text-blue-500">{totalBoosts}</span>
              <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Boosts</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-14 px-4">
        <div className="flex items-center justify-between mb-6 px-2">
           <h3 className="text-white font-black text-lg tracking-widest uppercase">My Drops</h3>
           <span className="text-[10px] text-gray-600 font-bold bg-white/5 px-3 py-1 rounded-full">{totalDrops} Assets</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {drops.map(drop => (
            <div key={drop.id} className="aspect-[3/4] bg-zinc-900 rounded-2xl relative overflow-hidden group shadow-lg border border-white/5">
              <img src={drop.video_url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
              <div className="absolute top-2 left-2 flex flex-col gap-2 z-20">
                <button onClick={() => setDropToDelete(drop.id)} className="p-2 bg-red-500/20 hover:bg-red-500 rounded-full text-white backdrop-blur-md transition-all active:scale-75"><Trash2 size={14} /></button>
                <button onClick={() => { setDropToEdit(drop); setEditDescription(drop.description); }} className="p-2 bg-blue-500/20 hover:bg-blue-500 rounded-full text-white backdrop-blur-md transition-all active:scale-75"><Pencil size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showSettings && (
        <div className="fixed inset-0 bg-black z-[100] flex flex-col animate-in slide-in-from-bottom duration-500">
          <div className="pt-12 pb-5 px-6 border-b border-white/10 flex justify-between items-center bg-black backdrop-blur-md shrink-0">
            <h2 className="text-2xl font-black text-white tracking-widest uppercase">Settings</h2>
            <button onClick={() => { setShowSettings(false); setActiveSettingModal(null); }} className="p-2.5 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all active:scale-90"><X size={20}/></button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-3 hide-scrollbar pb-32">
            {!activeSettingModal ? (
              <div className="space-y-3">
                {['עריכת פרופיל', 'התראות', 'פרטיות ואבטחה', 'אודות DOP'].map((item) => (
                  <button key={item} onClick={() => setActiveSettingModal(item)} className="w-full flex justify-between items-center p-5 bg-zinc-900/50 rounded-[1.5rem] border border-white/5 text-white font-bold active:scale-98 transition-all hover:bg-zinc-900">
                    {item} <ChevronLeft size={18} className="text-gray-600" />
                  </button>
                ))}
              </div>
            ) : renderSettingContent()}
          </div>
        </div>
      )}

      {dropToDelete && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[110] flex items-center justify-center p-6">
          <div className="bg-[#0a0a0a] border border-white/10 rounded-[2.5rem] p-8 w-full max-w-sm text-center animate-in zoom-in-95 duration-200 shadow-2xl">
            <div className="w-20 h-20 bg-red-500/5 rounded-full flex items-center justify-center mx-auto mb-6 border border-red-500/10 shadow-[0_0_30px_rgba(239,68,68,0.1)]"><Trash2 size={32} className="text-red-500" /></div>
            <h3 className="text-2xl font-black text-white mb-2 tracking-tight">מחיקת דרופ</h3>
            <p className="text-gray-500 text-sm mb-8 leading-relaxed px-4">האם אתה בטוח שברצונך למחוק את הדרופ הזה? לא ניתן יהיה לשחזר אותו מהשרת.</p>
            <div className="flex gap-3">
              <button onClick={() => setDropToDelete(null)} className="flex-1 py-4 bg-white/5 rounded-2xl text-white font-bold border border-white/5">ביטול</button>
              <button onClick={confirmDelete} className="flex-1 py-4 bg-red-500 rounded-2xl text-white font-black shadow-lg shadow-red-500/20 active:scale-95 transition-all">מחק</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default UserProfile;
