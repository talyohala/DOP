import React, { useState, useEffect } from 'react';
import { Aperture, Ghost, Zap, Skull } from 'lucide-react';
import { supabase } from '../supabase';

const BlackHole = () => {
  const [expiredDrops, setExpiredDrops] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchExpiredDrops();
  }, []);

  const fetchExpiredDrops = async () => {
    const now = new Date().toISOString();
    // שולף רק דרופים שהזמן שלהם עבר
    const { data } = await supabase
      .from('dop_videos')
      .select('*, users:user_id(username, has_halo)')
      .lt('expires_at', now)
      .order('expires_at', { ascending: false })
      .limit(50); // מגביל ל-50 האחרונים כדי לא להעמיס
      
    if (data) setExpiredDrops(data);
    setLoading(false);
  };

  return (
    <div className="h-[100dvh] w-full bg-[#030005] overflow-y-auto pb-28 hide-scrollbar relative" dir="rtl">
      
      {/* רקע חלל עמוק וסגול */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-[#030005] to-[#030005] pointer-events-none"></div>

      {/* כותרת עליונה */}
      <div className="pt-16 pb-8 px-6 relative z-10 flex flex-col items-center border-b border-purple-500/10 bg-black/40 backdrop-blur-xl shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
        <div className="relative mb-4">
          <div className="absolute inset-0 bg-purple-600/30 blur-2xl rounded-full animate-pulse"></div>
          <Aperture size={48} className="text-purple-400 animate-[spin_8s_linear_infinite] drop-shadow-[0_0_15px_rgba(168,85,247,0.8)] relative z-10" />
        </div>
        <h1 className="text-3xl font-black text-white tracking-widest drop-shadow-lg mb-2">החור השחור</h1>
        <p className="text-sm text-purple-300/70 font-bold tracking-wider flex items-center gap-2">
          <Ghost size={16} /> ארכיון הרפאים של DOP
        </p>
        <div className="mt-4 px-4 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded-full text-xs font-mono text-purple-300">
          {expiredDrops.length} נכסים אבודים
        </div>
      </div>

      {/* גריד הרפאים */}
      <div className="mt-6 px-3 relative z-10">
        {loading ? (
          <div className="flex justify-center mt-20">
            <Aperture size={32} className="text-purple-500/50 animate-spin" />
          </div>
        ) : expiredDrops.length === 0 ? (
          <div className="flex flex-col items-center justify-center mt-20 p-8 bg-white/5 border border-white/5 rounded-[2rem]">
            <Aperture size={40} className="text-white/10 mb-4" />
            <span className="text-center text-gray-500 font-medium text-sm">
              החור השחור ריק כרגע.<br/>שום דרופ עדיין לא נשאב לכאן.
            </span>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {expiredDrops.map(drop => {
              const isImage = drop.video_url?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
              return (
                <div key={drop.id} className="aspect-[3/4] bg-zinc-950 relative overflow-hidden group rounded-3xl border border-purple-500/10 shadow-xl">
                  {/* אפקט שחור לבן שהופך לצבעוני בריחוף/לחיצה */}
                  {isImage ? (
                    <img src={drop.video_url} className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700" />
                  ) : (
                    <video src={drop.video_url} className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700" />
                  )}
                  
                  {/* שכבת מסתורין (Overlay) */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#030005] via-transparent to-transparent opacity-80 pointer-events-none"></div>

                  {/* מידע על הדרופ המת */}
                  <div className="absolute bottom-3 right-3 left-3 flex items-end justify-between z-10">
                    <div className="flex flex-col">
                      <span className={`text-xs font-bold ${drop.users?.has_halo ? 'text-yellow-400' : 'text-gray-400'}`}>
                        @{drop.users?.username || 'אנונימי'}
                      </span>
                      <span className="text-[10px] text-purple-400/80 font-mono mt-0.5 flex items-center gap-1">
                        <Skull size={10} /> נשאב
                      </span>
                    </div>
                    
                    <div className="bg-black/80 backdrop-blur-xl rounded-full px-2 py-1 flex items-center gap-1 border border-white/5">
                      <Zap size={10} className="text-gray-500" />
                      <span className="text-[10px] text-gray-400 font-bold">{drop.boosts || 0}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default BlackHole;
