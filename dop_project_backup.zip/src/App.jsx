import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { supabase, executeBoost } from './supabase';
import { playCoinSound } from './utils/sounds';
import AuthScreen from './components/AuthScreen';
import FloatingNav from './components/FloatingNav';
import DropCard from './components/DropCard';
import UserProfile from './components/UserProfile';
import Store from './components/Store';
import UploadScreen from './components/UploadScreen';
import BlackHole from './components/BlackHole';
import NotificationsScreen from './components/NotificationsScreen';
import SearchScreen from './components/SearchScreen';
import CrystalBoost from './components/CrystalBoost';

function App() {
  const [session, setSession] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [drops, setDrops] = useState([]);
  const [baseDrops, setBaseDrops] = useState([]); 
  const [activeTab, setActiveTab] = useState('home');
  const [showUpload, setShowUpload] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [boosts, setBoosts] = useState([]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => setSession(session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => setSession(session));
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    fetchUserProfile();
    fetchActiveDrops();

    const dropsChannel = supabase.channel('public:dop_videos')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'dop_videos' }, () => fetchActiveDrops())
      .subscribe();

    const userChannel = supabase.channel(`public:dop_users:${session.user.id}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'dop_users', filter: `id=eq.${session.user.id}` }, (payload) => {
        setCurrentUser(payload.new);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(dropsChannel);
      supabase.removeChannel(userChannel);
    };
  }, [session]);

  const fetchUserProfile = async () => {
    const { data } = await supabase.from('dop_users').select('*').eq('id', session.user.id).single();
    if (data) setCurrentUser(data);
  };

  const fetchActiveDrops = async () => {
    const now = new Date().toISOString();
    const { data: videos, error: vidError } = await supabase
      .from('dop_videos')
      .select('*')
      .gte('expires_at', now)
      .order('created_at', { ascending: false });

    if (vidError || !videos) return;
    if (videos.length === 0) { setDrops([]); return; }

    const userIds = [...new Set(videos.map(v => v.user_id).filter(Boolean))];
    let usersMap = {};
    if (userIds.length > 0) {
      const { data: users } = await supabase.from('dop_users').select('id, username, has_halo').in('id', userIds);
      if (users) users.forEach(u => { usersMap[u.id] = u; });
    }

    const combinedDrops = videos.map((v, index) => ({
      ...v,
      uniqueKey: `${v.id}_${index}`,
      users: usersMap[v.user_id] || { username: 'אנונימי' }
    }));

    setBaseDrops(combinedDrops);
    setDrops(combinedDrops);
  };

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight * 2 && baseDrops.length > 0) {
      const shuffled = [...baseDrops].sort(() => 0.5 - Math.random());
      const newDrops = shuffled.map((d, i) => ({ ...d, uniqueKey: `${d.id}_loop_${Date.now()}_${i}` }));
      setDrops((prev) => [...prev, ...newDrops]);
    }
  };

  const handleNavigation = (tab) => {
    if (tab === 'create') setShowUpload(true);
    else setActiveTab(tab);
  };

  const handleBoost = async (dropId, event) => {
    if (navigator.vibrate) navigator.vibrate(50);
    playCoinSound();
    const newBoost = { id: Date.now(), x: event?.clientX || window.innerWidth/2, y: event?.clientY || window.innerHeight/2 };
    setBoosts((prev) => [...prev, newBoost]);
    try { await executeBoost(dropId, 5); } catch (error) { console.error('Boost failed:', error.message); }
  };

  const removeBoostAnimation = (id) => setBoosts((prev) => prev.filter((b) => b.id !== id));

  if (!session) return <AuthScreen onLoginSuccess={() => console.log('Logged in!')} />;

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return (
          <div className="h-[100dvh] w-full bg-black overflow-y-scroll snap-y snap-mandatory hide-scrollbar" onScroll={handleScroll}>
            {drops.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-500 font-mono text-lg">אין דרופים פעילים. הגיע הזמן להעלות!</div>
            ) : (
              drops.map((drop) => (
                <div key={drop.uniqueKey} className="relative w-full h-[100dvh] snap-start snap-always" onDoubleClick={(e) => handleBoost(drop.id, e)}>
                  <DropCard drop={drop} onBoost={(e) => handleBoost(drop.id, e)} onSearch={() => setShowSearch(true)} />
                </div>
              ))
            )}
            {boosts.map((boost) => <CrystalBoost key={boost.id} triggerId={boost.id} x={boost.x} y={boost.y} onComplete={() => removeBoostAnimation(boost.id)} />)}
          </div>
        );
      case 'blackhole': return <BlackHole drops={drops} onBoost={handleBoost} />;
      case 'profile': return <UserProfile user={currentUser} drops={drops.filter(d => d.user_id === session.user.id)} />;
      case 'notifications': return <NotificationsScreen user={session.user} />;
      case 'store': return <Store userCoins={currentUser?.dop_coins} onPurchase={(item) => console.log('Buy:', item)} />;
      default: return null;
    }
  };

  return (
    <div className="bg-black min-h-[100dvh] w-full font-sans overflow-hidden text-white relative" dir="rtl">
      
      {/* כפתור התראות ממוקם קבוע למעלה משמאל כשהמשתמש בפיד */}
      {activeTab === 'home' && !showSearch && (
        <button onClick={() => setActiveTab('notifications')} className="fixed top-12 right-4 z-30 flex items-center justify-center w-11 h-11 bg-black/40 backdrop-blur-xl border border-white/20 rounded-full text-white active:scale-90 transition-all shadow-2xl">
          <Bell size={22} />
        </button>
      )}

      {renderScreen()}
      <FloatingNav activeTab={activeTab} setActiveTab={handleNavigation} />
      
      {showUpload && <UploadScreen onClose={() => setShowUpload(false)} onUploadComplete={() => { setShowUpload(false); fetchActiveDrops(); }} />}
      {showSearch && <SearchScreen onClose={() => setShowSearch(false)} />}
    </div>
  );
}

export default App;
