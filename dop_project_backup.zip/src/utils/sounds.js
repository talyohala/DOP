export const playCoinSound = () => {
  const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3');
  audio.volume = 0.6;
  audio.play().catch(() => {}); // מתעלם משגיאות אם הטלפון על השתק
};

export const playPurchaseSound = () => {
  const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2003/2003-preview.mp3');
  audio.volume = 0.7;
  audio.play().catch(() => {});
};
