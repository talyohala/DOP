import React, { useState, useRef } from 'react';
import { X, CheckCircle2, AlertCircle, ImageIcon, Film } from 'lucide-react';
import { supabase } from '../supabase';

const UploadScreen = ({ onClose, onUploadComplete }) => {
  const [file, setFile] = useState(null);
  const [description, setDescription] = useState('');
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(null);
  const [notification, setNotification] = useState(null);
  const fileInputRef = useRef(null);

  const showToast = (message, type) => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  const handleUpload = async () => {
    if (!file) return showToast('בחר קובץ קודם', 'error');
    setUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('אנא התחבר מחדש');

      const fileExt = file.name.split('.').pop();
      const fileName = `${session.user.id}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage.from('dop_videos').upload(fileName, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from('dop_videos').getPublicUrl(fileName);

      const { error: dbError } = await supabase.from('dop_videos').insert([{
        user_id: session.user.id,
        video_url: publicUrl,
        description: description,
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      }]);

      if (dbError) throw dbError;

      showToast('הדרופ באוויר', 'success');
      setTimeout(() => onUploadComplete(), 1500);
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-2xl z-50 flex flex-col items-center justify-end p-4 pb-24 sm:justify-center" dir="rtl">
      
      {notification && (
        <div className={`fixed top-12 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full backdrop-blur-xl border shadow-2xl flex items-center gap-3 transition-all animate-in fade-in slide-in-from-top-4 z-[60] ${
          notification.type === 'success' ? 'bg-green-500/20 border-green-500/30 text-green-300' : 'bg-red-500/20 border-red-500/30 text-red-300'
        }`}>
          {notification.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <p className="font-bold text-sm tracking-wide">{notification.message}</p>
        </div>
      )}

      <div className="w-full max-w-sm bg-[#18181b]/95 rounded-[2.5rem] border border-white/10 p-6 flex flex-col items-center shadow-2xl relative animate-in slide-in-from-bottom-10">
        <button onClick={onClose} className="absolute -top-14 right-0 p-3 bg-white/10 rounded-full text-white active:scale-90 transition-all">
          <X size={20} />
        </button>

        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full aspect-square bg-[#27272a]/50 rounded-[2rem] flex flex-col items-center justify-center cursor-pointer active:scale-95 transition-all mb-6 overflow-hidden relative group border border-white/5"
        >
          {preview ? (
            file.type.startsWith('image/') ? (
              <img src={preview} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <video src={preview} className="w-full h-full object-cover" />
            )
          ) : (
            <div className="flex flex-col items-center text-gray-400 gap-3">
              <div className="flex gap-4">
                <ImageIcon size={28} strokeWidth={1.5} />
                <Film size={28} strokeWidth={1.5} />
              </div>
            </div>
          )}
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/*" onChange={handleFileSelect} disabled={uploading} />
        </div>

        <input 
          type="text" 
          placeholder="כמה מילים על הדרופ..." 
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full bg-transparent border-b border-white/10 p-3 text-white placeholder-gray-500 outline-none focus:border-white/40 transition-all mb-8 text-center"
          disabled={uploading}
        />

        <button 
          onClick={handleUpload}
          disabled={uploading || !file}
          className="w-full bg-white text-black font-bold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50 disabled:active:scale-100"
        >
          <span className="tracking-widest text-lg">{uploading ? 'מעלה...' : 'העלאה'}</span>
        </button>
      </div>
    </div>
  );
};

export default UploadScreen;
