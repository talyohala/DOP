import React, { useState, useEffect } from 'react';
import { Bell, Zap, MessageCircle, CheckCircle2 } from 'lucide-react';
import { supabase } from '../supabase';

const NotificationsScreen = ({ user }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchNotifications();
      // סימון כל ההתראות כנקראו ברגע שפותחים את המסך
      supabase.from('dop_notifications').update({ is_read: true }).eq('user_id', user.id).then();
    }
  }, [user]);

  const fetchNotifications = async () => {
    const { data } = await supabase
      .from('dop_notifications')
      .select('*, actor:actor_id(username, avatar_url, has_halo)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(30);

    if (data) setNotifications(data);
    setLoading(false);
  };

  return (
    <div className="min-h-[100dvh] bg-[#121212] text-white p-4 pt-10 pb-24" dir="rtl">
      <div className="flex items-center justify-between mb-8 border-b border-white/10 pb-4">
        <h1 className="text-2xl font-black tracking-widest flex items-center gap-2">
          <Bell className="text-white" /> התראות
        </h1>
      </div>

      <div className="space-y-3">
        {loading ? (
          <div className="text-center text-gray-500 animate-pulse mt-10">טוען התראות...</div>
        ) : notifications.length === 0 ? (
          <div className="text-center text-gray-500 mt-10">אין לך התראות חדשות.</div>
        ) : (
          notifications.map((notif) => (
            <div key={notif.id} className={`p-4 rounded-2xl border flex items-center gap-4 ${notif.is_read ? 'bg-white/5 border-white/5' : 'bg-white/10 border-white/20'}`}>
              <div className="w-12 h-12 rounded-full bg-zinc-800 shrink-0 overflow-hidden border border-white/10 flex items-center justify-center relative">
                {notif.actor?.avatar_url ? <img src={notif.actor.avatar_url} className="w-full h-full object-cover" /> : <span className="text-white/50 text-xs">@</span>}
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#121212] flex items-center justify-center">
                  {notif.type === 'boost' ? <Zap size={12} className="text-yellow-400 fill-yellow-400" /> : <MessageCircle size={12} className="text-blue-400 fill-blue-400" />}
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm">
                  <span className={`font-bold ${notif.actor?.has_halo ? 'text-yellow-400' : 'text-white'}`}>@{notif.actor?.username} </span>
                  {notif.type === 'boost' ? 'נתן בוסט לדרופ שלך!' : 'הגיב על הדרופ שלך!'}
                </p>
                <span className="text-xs text-gray-500 mt-1">{new Date(notif.created_at).toLocaleTimeString('he-IL', {hour: '2-digit', minute:'2-digit'})}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
export default NotificationsScreen;
