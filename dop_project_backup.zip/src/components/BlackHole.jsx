import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Ghost, Play } from 'lucide-react';

const BlackHole = () => {
  const [deadDrops, setDeadDrops] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDeadDrops = async () => {
      const now = new Date().toISOString();
      
      // שולפים רק סרטונים שהתאריך שלהם קטן מעכשיו (כלומר, פג תוקפם)
      const { data } = await supabase
        .from('dop_videos')
        .select('*')
        .lt('expires_at', now)
        .order('expires_at', { ascending: false })
        .limit(30); // מציג את ה-30 האחרונים שמתו
      
      if (data) setDeadDrops(data);
      setLoading(false);
    };
    
    fetchDeadDrops();
  }, []);

  return (
    <div className="min-h-[100dvh] bg-[#0a0a0a] text-white p-4 pt-10 pb-24" dir="rtl">
      <div className="flex flex-col items-center justify-center mb-8 border-b border-white/5 pb-6">
        <Ghost size={48} className="text-gray-600 mb-2 animate-pulse" />
        <h1 className="text-2xl font-black tracking-widest text-gray-400">החור השחור</h1>
        <p className="text-xs text-gray-600 mt-1 uppercase tracking-widest">דרופים שזמנם עבר</p>
      </div>

      {loading ? (
         <div className="text-center text-gray-600 mt-20 font-mono animate-pulse">שואב נתונים...</div>
      ) : deadDrops.length === 0 ? (
         <div className="text-center text-gray-600 mt-20 font-mono">החור השחור ריק. בינתיים.</div>
      ) : (
        <div className="grid grid-cols-3 gap-1">
          {deadDrops.map((drop) => {
            const isImage = drop.video_url?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
            return (
              <div key={drop.id} className="aspect-[3/4] bg-zinc-900 relative group overflow-hidden border border-white/5 cursor-pointer">
                {/* שכבת כהות שמתבהרת בלחיצה */}
                <div className="absolute inset-0 bg-black/60 z-10 group-active:bg-black/20 transition-all" />
                
                {isImage ? (
                  <img src={drop.video_url} className="w-full h-full object-cover grayscale opacity-50 group-active:grayscale-0 transition-all" />
                ) : (
                  <>
                    <video src={drop.video_url} className="w-full h-full object-cover grayscale opacity-50 group-active:grayscale-0 transition-all" />
                    <div className="absolute top-2 right-2 z-20 text-white/30"><Play size={16}/></div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default BlackHole;
