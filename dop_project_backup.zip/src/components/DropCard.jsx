import React, { useState } from 'react';
import { Zap, Clock, ShieldAlert, Crown, MessageCircle, Search, ChevronDown, ChevronUp } from 'lucide-react';
import CommentsOverlay from './CommentsOverlay';

const DropCard = ({ drop, onBoost, onSearch }) => {
  const [showComments, setShowComments] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const timeLeftMs = new Date(drop.expires_at).getTime() - Date.now();
  const timeLeftMinutes = Math.max(0, Math.floor(timeLeftMs / 60000));
  const isImage = drop.video_url?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
  const hasHalo = drop.users?.has_halo;
  const hasLongDesc = drop.description && drop.description.length > 50;

  return (
    <div className="relative w-full h-full bg-zinc-900 flex items-center justify-center overflow-hidden" dir="rtl">
      {isImage ? (
        <img src={drop.video_url} alt="Drop" className="absolute inset-0 w-full h-full object-cover" />
      ) : (
        <video src={drop.video_url} autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover" />
      )}
      
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/60 to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black/80 via-black/40 to-transparent pointer-events-none" />

      {/* שם משתמש - שמאל למעלה */}
      <div className="absolute top-12 left-4 z-10 flex items-center h-11 pointer-events-none text-left">
        <h3 className={`font-black text-lg drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] flex items-center gap-2 ${hasHalo ? 'text-yellow-400' : 'text-white'}`}>
          {hasHalo && <Crown size={18} className="text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,1)]" />}
          @{drop.users?.username || 'אנונימי'}
        </h3>
      </div>

      {/* כפתורי פעולה - ימין למטה */}
      <div className="absolute bottom-28 right-4 flex flex-col items-center gap-5 z-20">
        <div className="flex flex-col items-center gap-1">
          <div className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md border shadow-lg ${timeLeftMinutes < 60 ? 'bg-red-500/20 border-red-500/50 animate-pulse text-red-500' : 'bg-black/40 border-white/20 text-white'}`}>
            {timeLeftMinutes < 60 ? <ShieldAlert size={18} /> : <Clock size={18} />}
          </div>
          <span className="text-white font-mono font-bold text-xs drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">{timeLeftMinutes} דק'</span>
        </div>
        
        <button onClick={onSearch} className="group relative w-11 h-11 bg-black/40 border border-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all">
          <Search size={20} className="text-white" />
        </button>

        <button onClick={() => setShowComments(true)} className="group relative w-11 h-11 bg-black/40 border border-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all">
          <MessageCircle size={20} className="text-white" />
        </button>

        <button onClick={onBoost} className="group relative w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.3)] active:scale-95 transition-all">
          <Zap size={24} className="text-black group-hover:fill-black" />
        </button>
      </div>

      {/* תיאור - מיושר לצד שמאל למטה */}
      <div className="absolute bottom-28 left-4 w-2/3 z-10 pointer-events-auto flex flex-col items-start text-left" dir="ltr">
        <p className={`text-white text-sm font-medium drop-shadow-[0_2px_5px_rgba(0,0,0,0.9)] leading-tight transition-all duration-300 ${isExpanded ? '' : 'line-clamp-2'}`}>
          {drop.description}
        </p>
        {hasLongDesc && (
          <button 
            onClick={(e) => { e.stopPropagation(); setIsExpanded(!isExpanded); }} 
            className="text-white/80 hover:text-white mt-2 drop-shadow-[0_2px_5px_rgba(0,0,0,0.9)] transition-all active:scale-90"
          >
            {isExpanded ? <ChevronUp size={22} /> : <ChevronDown size={22} />}
          </button>
        )}
      </div>

      {showComments && <CommentsOverlay videoId={drop.id} onClose={() => setShowComments(false)} />}
    </div>
  );
};
export default DropCard;
