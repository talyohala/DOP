import React, { useState } from 'react';
import { supabase } from '../supabase';
import { Mail, Lock, ArrowLeft, AlertCircle } from 'lucide-react';

const AuthScreen = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true); setError(null);
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        onLoginSuccess();
      } else {
        const { data, error } = await supabase.auth.signUp({ 
          email, password, options: { data: { username } }
        });
        if (error) throw error;
        if (data.user) {
          await supabase.from('dop_users').insert([{ id: data.user.id, username: username || email.split('@')[0] }]);
        }
        onLoginSuccess();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] bg-[#121212] flex flex-col items-center justify-center p-6" dir="rtl">
      <div className="w-full max-w-sm flex flex-col items-center">
        
        {/* כותרת נקייה וגדולה */}
        <h1 className="text-5xl font-black text-white tracking-[0.2em] mb-12">DOP</h1>

        {error && (
          <div className="mb-6 w-full p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-2 text-red-400 text-sm">
            <AlertCircle size={16} />
            <p>{error}</p>
          </div>
        )}

        <form onSubmit={handleAuth} className="w-full space-y-5 flex flex-col items-center">
          {!isLogin && (
            <div className="relative w-full">
              <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-gray-500 font-bold">@</div>
              <input type="text" placeholder="שם משתמש" value={username} onChange={(e) => setUsername(e.target.value)} required={!isLogin} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white placeholder-gray-500 outline-none focus:border-white/30 transition-all" />
            </div>
          )}
          
          <div className="relative w-full">
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none"><Mail size={20} className="text-gray-500" /></div>
            <input type="email" placeholder="אימייל" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white placeholder-gray-500 outline-none focus:border-white/30 transition-all" />
          </div>
          
          <div className="relative w-full">
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none"><Lock size={20} className="text-gray-500" /></div>
            <input type="password" placeholder="סיסמה" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white placeholder-gray-500 outline-none focus:border-white/30 transition-all" />
          </div>
          
          {/* כפתור כניסה עגול עם חץ */}
          <div className="pt-8">
            <button type="submit" disabled={loading} className="w-16 h-16 bg-white rounded-full flex items-center justify-center active:scale-95 transition-transform shadow-[0_0_30px_rgba(255,255,255,0.15)] disabled:opacity-50">
              <ArrowLeft size={28} className="text-black" />
            </button>
          </div>
        </form>

        <div className="mt-12 text-center">
          <button type="button" onClick={() => { setIsLogin(!isLogin); setError(null); }} className="text-gray-500 text-sm hover:text-white transition-colors">
            {isLogin ? "אין לך חשבון? הירשם" : "כבר רשום? התחבר"}
          </button>
        </div>

      </div>
    </div>
  );
};
export default AuthScreen;
