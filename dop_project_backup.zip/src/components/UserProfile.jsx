import React, { useRef, useState } from 'react';
import { Clock, Zap, Grid, LogOut, Camera, Crown } from 'lucide-react';
import { supabase } from '../supabase';

const UserProfile = ({ user, drops = [] }) => {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const timeBalance = user?.time_balance || 0;
  const days = Math.floor(timeBalance / 1440);
  const hours = Math.floor((timeBalance % 1440) / 60);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  const handleAvatarUpload = async (e) => {
    try {
      setUploading(true);
      const file = e.target.files[0];
      if (!file) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage.from('avatars').upload(fileName, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(fileName);

      const { error: updateError } = await supabase.from('dop_users').update({ avatar_url: publicUrl }).eq('id', user.id);
      if (updateError) throw updateError;

      window.location.reload();
    } catch (error) {
      alert('שגיאה בהעלאה: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const hasHalo = user?.has_halo;
  const ringColor = hasHalo ? "border-yellow-400 shadow-[0_0_40px_rgba(250,204,21,0.4)]" : "border-white/20 shadow-[0_0_30px_rgba(255,255,255,0.1)]";

  return (
    <div className="min-h-[100dvh] bg-[#121212] text-white pb-24" dir="rtl">
      <div className="relative pt-16 pb-8 px-4 flex flex-col items-center bg-gradient-to-b from-white/5 to-transparent border-b border-white/10">
        
        <button onClick={handleLogout} className="absolute top-6 left-4 p-3 bg-white/5 border border-white/10 rounded-full text-red-400 hover:text-red-300 active:scale-95 transition-all shadow-lg z-50 flex items-center gap-2">
          <LogOut size={18} />
          <span className="text-xs font-bold uppercase tracking-widest">יציאה</span>
        </button>

        <div className={`relative w-28 h-28 mb-4 group cursor-pointer rounded-full border-2 ${ringColor} transition-all`} onClick={() => fileInputRef.current?.click()}>
          {user?.avatar_url ? (
            <img src={user.avatar_url} alt="Profile" className="w-full h-full rounded-full object-cover" />
          ) : (
            <div className="w-full h-full bg-zinc-800 rounded-full flex items-center justify-center">
              <span className="text-4xl font-bold text-white/50">@</span>
            </div>
          )}
          
          <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            {uploading ? <span className="text-xs font-bold animate-pulse">מעלה...</span> : <Camera size={28} className="text-white/80" />}
          </div>
          <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
        </div>

        {/* כאן העברנו את הכתר להיות ליד השם */}
        <h2 className={`text-2xl font-bold flex items-center justify-center gap-2 ${hasHalo ? 'text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]' : ''}`}>
          @{user?.username || 'משתמש'}
          {hasHalo && <Crown size={24} className="text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.8)]" />}
        </h2>
        
        <div className="flex gap-6 mt-6 w-full max-w-xs">
          <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-md">
            <Clock className="text-gray-400" />
            <div>
              <span className="block font-mono font-bold text-lg">{days}d {hours}h</span>
              <span className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">בנק זמן</span>
            </div>
          </div>
          <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-md">
            <Zap className="text-yellow-500" />
            <div>
              <span className="block font-mono font-bold text-lg text-yellow-500">{user?.dop_coins?.toFixed(1) || '0.0'}</span>
              <span className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">DOP</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center gap-2 mb-4 text-gray-400">
          <Grid size={20} />
          <span className="font-bold text-sm tracking-widest uppercase">הדרופים שלי</span>
        </div>
        <div className="grid grid-cols-3 gap-1">
          {drops.map((drop) => {
             const isImage = drop.video_url?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
             return (
              <div key={drop.id} className="aspect-[3/4] bg-zinc-900 overflow-hidden relative border border-white/5">
                {isImage ? (
                   <img src={drop.video_url} className="w-full h-full object-cover opacity-80" />
                ) : (
                   <video src={drop.video_url} className="w-full h-full object-cover opacity-80" />
                )}
              </div>
             );
          })}
        </div>
      </div>
    </div>
  );
};
export default UserProfile;
