import React, { useState, useEffect, useRef } from 'react';
import { X, Send } from 'lucide-react';
import { supabase } from '../supabase';

const CommentsOverlay = ({ videoId, onClose }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user));
    fetchComments();
    
    const channel = supabase.channel(`comments_${videoId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'dop_comments', filter: `video_id=eq.${videoId}` }, () => {
         fetchComments();
      }).subscribe();

    return () => supabase.removeChannel(channel);
  }, [videoId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  const fetchComments = async () => {
    const { data: cData } = await supabase.from('dop_comments').select('*').eq('video_id', videoId).order('created_at', { ascending: true });
    
    if (cData && cData.length > 0) {
       const userIds = [...new Set(cData.map(c => c.user_id))];
       const { data: uData } = await supabase.from('dop_users').select('id, username, avatar_url, has_halo').in('id', userIds);
       const usersMap = {};
       if (uData) uData.forEach(u => usersMap[u.id] = u);
       
       const combined = cData.map(c => ({ ...c, user: usersMap[c.user_id] || { username: 'אנונימי' } }));
       setComments(combined);
    } else {
       setComments([]);
    }
    setLoading(false);
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;
    const temp = newComment;
    setNewComment('');
    await supabase.from('dop_comments').insert([{ video_id: videoId, user_id: user.id, content: temp }]);
  };

  return (
    <div 
      className="absolute inset-x-0 bottom-0 h-2/3 bg-[#0a0a0a]/95 backdrop-blur-2xl rounded-t-3xl border-t border-white/10 z-50 flex flex-col animate-in slide-in-from-bottom-full duration-300" 
      dir="rtl" 
      onClick={(e) => e.stopPropagation()}
      onTouchMove={(e) => e.stopPropagation()}
      onWheel={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <h3 className="font-bold text-lg text-white tracking-widest">תגובות</h3>
        <button onClick={onClose} className="p-2 bg-white/5 rounded-full text-white active:scale-95 transition-all"><X size={20}/></button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 hide-scrollbar">
        {loading ? <div className="text-center text-gray-500 text-sm mt-4 animate-pulse">טוען תגובות...</div> : comments.length === 0 ? <div className="text-center text-gray-500 text-sm mt-4">תהיה הראשון להגיב! 💬</div> : comments.map(c => (
          <div key={c.id} className="flex items-start gap-3">
             <div className={`w-8 h-8 rounded-full bg-zinc-800 overflow-hidden shrink-0 border ${c.user.has_halo ? 'border-yellow-400' : 'border-white/10'} flex items-center justify-center`}>
                {c.user.avatar_url ? <img src={c.user.avatar_url} className="w-full h-full object-cover" /> : <span className="text-xs text-white/50">@</span>}
             </div>
             <div className="flex-1 bg-white/5 rounded-2xl rounded-tr-none p-3 border border-white/5">
                <div className="flex items-center gap-1 mb-1">
                  <span className={`font-bold text-xs ${c.user.has_halo ? 'text-yellow-400 drop-shadow-[0_0_5px_rgba(250,204,21,0.5)]' : 'text-gray-300'}`}>@{c.user.username}</span>
                </div>
                <p className="text-sm text-white leading-snug">{c.content}</p>
             </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="p-4 border-t border-white/5 flex gap-2">
        <input type="text" value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="הוסף תגובה..." className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 text-sm text-white outline-none focus:border-white/30 transition-all" />
        <button type="submit" disabled={!newComment.trim()} className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-black shrink-0 disabled:opacity-50 active:scale-95">
           <Send size={16} className="-ml-1" />
        </button>
      </form>
    </div>
  );
}
export default CommentsOverlay;
