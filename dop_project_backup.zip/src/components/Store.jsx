import React, { useState } from 'react';
import { Snowflake, Clock, Crown, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '../supabase';
import { playPurchaseSound } from '../utils/sounds';

const STORE_ITEMS = [
  { id: 'freeze', name: 'הקפאה קריוגנית', desc: 'מוסיף 12 שעות לדרופ האחרון שהעלית. מצוין ללילה.', price: 5, icon: <Snowflake size={24} /> },
  { id: 'siphon', name: 'שואב זמן', desc: 'בקרוב: מאפשר לשאוב זמן מדרופ מתחרה.', price: 10, icon: <Clock size={24} /> },
  { id: 'halo', name: 'הילת VIP', desc: 'הילה מוזהבת לפרופיל שתמשוך יותר תשומת לב בפיד לכל החיים.', price: 15, icon: <Crown size={24} /> },
];

const Store = ({ userCoins = 0 }) => {
  const [loadingId, setLoadingId] = useState(null);
  const [notification, setNotification] = useState(null);

  const showToast = (message, type) => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handlePurchase = async (item) => {
    try {
      setLoadingId(item.id);
      const { error } = await supabase.rpc('purchase_store_item', { item_id: item.id });
      
      if (error) throw error;
      
      playPurchaseSound(); // מנגן צליל קופה רושמת!
      showToast(`רכשת בהצלחה את ${item.name}! 🚀`, 'success');
      setTimeout(() => window.location.reload(), 2000);
    } catch (err) {
      if (err.message.includes('Not enough coins')) {
        showToast('אין לך מספיק מטבעות DOP!', 'error');
      } else {
        showToast('שגיאה ברכישה: ' + err.message, 'error');
      }
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div className="min-h-[100dvh] bg-[#121212] text-white p-4 pt-10 pb-24 relative" dir="rtl">
      
      {notification && (
        <div className={`fixed top-12 left-1/2 -translate-x-1/2 w-11/12 max-w-sm z-50 p-4 rounded-2xl backdrop-blur-xl border shadow-2xl flex items-center gap-3 transition-all ${
          notification.type === 'success' ? 'bg-green-500/20 border-green-500/50 text-green-300' : 'bg-red-500/20 border-red-500/50 text-red-300'
        }`}>
          {notification.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
          <p className="font-bold text-sm">{notification.message}</p>
        </div>
      )}

      <div className="flex items-center justify-between mb-8 border-b border-white/10 pb-4">
        <h1 className="text-2xl font-black tracking-widest">השוק השחור</h1>
        <div className="text-right">
          <span className="block text-xl font-mono font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]">{userCoins.toFixed(1)}</span>
          <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">מטבעות DOP</span>
        </div>
      </div>
      <div className="space-y-4">
        {STORE_ITEMS.map((item) => (
          <div key={item.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex items-start justify-between gap-4">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-white shrink-0">{item.icon}</div>
            <div className="flex-1">
              <h3 className="font-bold text-lg">{item.name}</h3>
              <p className="text-sm text-gray-400 mt-1 leading-snug">{item.desc}</p>
            </div>
            <button 
              onClick={() => handlePurchase(item)} 
              disabled={loadingId === item.id}
              className="bg-white text-black font-bold py-2 px-4 rounded-xl flex items-center gap-1 active:scale-95 transition-transform shrink-0 disabled:opacity-50"
            >
              {loadingId === item.id ? '...' : item.price} <span className="text-xs">DOP</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Store;
