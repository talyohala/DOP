import React from 'react';
import { Home, User, ShoppingBag, Plus, Aperture } from 'lucide-react';

const FloatingNav = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'home', icon: <Home size={26} /> },
    { id: 'blackhole', icon: <Aperture size={26} /> }, // סמל מערבולת/שער לחור השחור
    { id: 'create', icon: <Plus size={30} strokeWidth={2.5} className="text-black" />, isMain: true },
    { id: 'store', icon: <ShoppingBag size={26} /> },
    { id: 'profile', icon: <User size={26} /> },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-[#1c1c1e]/95 backdrop-blur-3xl border-t border-white/5 px-6 pb-6 pt-3 flex items-center justify-between z-40 shadow-[0_-10px_40px_rgba(0,0,0,0.3)]">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveTab(item.id)}
          className={`relative flex flex-col items-center justify-center transition-all duration-300 ${
            item.isMain 
              ? 'bg-white rounded-2xl w-14 h-10 active:scale-95 shadow-[0_5px_15px_rgba(255,255,255,0.2)]' 
              : `active:scale-90 p-2 ${activeTab === item.id ? 'text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.8)] scale-110' : 'text-gray-500 hover:text-gray-400'}`
          }`}
        >
          {item.icon}
        </button>
      ))}
    </div>
  );
};
export default FloatingNav;
